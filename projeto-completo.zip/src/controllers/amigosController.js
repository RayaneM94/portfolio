const db = require('../models/db');

exports.listarAmigos = async (req, res) => {
  try {
    const userId = req.usuario.id;
    const [rows] = await db.query(
      `SELECT u.id, u.nome, u.email 
       FROM amigos a 
       JOIN usuarios u ON a.amigo_id = u.id 
       WHERE a.usuario_id = ?`, 
      [userId]
    );
    res.json(rows);
  } catch (err) {
    console.error('Erro ao listar amigos:', err);
    res.status(500).json({ error: 'Erro interno ao listar amigos.' });
  }
};

exports.adicionarAmigo = async (req, res) => {
  try {
    const userId = req.usuario.id;
    const amigoId = parseInt(req.params.id);

    if (userId === amigoId) {
      return res.status(400).json({ error: 'Você não pode se adicionar como amigo!' });
    }

    const [verifica] = await db.query(
      'SELECT * FROM amigos WHERE usuario_id = ? AND amigo_id = ?', 
      [userId, amigoId]
    );

    if (verifica.length > 0) {
      return res.status(400).json({ error: 'Amigo já adicionado!' });
    }

    await db.query(
      'INSERT INTO amigos (usuario_id, amigo_id) VALUES (?, ?)', 
      [userId, amigoId]
    );

    res.json({ message: 'Amigo adicionado com sucesso!' });
  } catch (err) {
    console.error('Erro ao adicionar amigo:', err);
    res.status(500).json({ error: 'Erro interno ao adicionar amigo.' });
  }
};

exports.removerAmigo = async (req, res) => {
  try {
    const userId = req.usuario.id;
    const amigoId = parseInt(req.params.id);

    await db.query(
      'DELETE FROM amigos WHERE usuario_id = ? AND amigo_id = ?', 
      [userId, amigoId]
    );

    res.json({ message: 'Amigo removido com sucesso!' });
  } catch (err) {
    console.error('Erro ao remover amigo:', err);
    res.status(500).json({ error: 'Erro interno ao remover amigo.' });
  }
};
