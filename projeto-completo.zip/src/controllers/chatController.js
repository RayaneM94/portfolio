const db = require('../models/db');

// ✅ Chat Global
exports.buscarMensagensGlobal = async (req, res) => {
  try {
    const [mensagens] = await db.query(`
      SELECT c.*, u.nome 
      FROM chat c
      JOIN usuarios u ON c.usuario_id = u.id
      ORDER BY c.data ASC
    `);
    res.json(mensagens);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao buscar mensagens globais' });
  }
};

// ✅ Chat com Amigos
exports.buscarMensagensAmigos = async (req, res) => {
  const usuarioId = req.usuario.id;
  try {
    const [mensagens] = await db.query(`
      SELECT c.*, u.nome 
      FROM chat c
      JOIN usuarios u ON c.usuario_id = u.id
      WHERE c.usuario_id = ? 
         OR c.usuario_id IN (
           SELECT amigo_id FROM amigos WHERE usuario_id = ?
         )
      ORDER BY c.data ASC
    `, [usuarioId, usuarioId]);
    res.json(mensagens);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao buscar mensagens dos amigos' });
  }
};

// ✅ Enviar Mensagem
exports.enviarMensagem = async (req, res) => {
  try {
    const usuarioId = req.usuario.id;
    const { mensagem, tipo } = req.body; // tipo = 'global' ou 'amigo'

    if (!mensagem || !tipo) {
      return res.status(400).json({ error: 'Mensagem e tipo são obrigatórios' });
    }

    await db.query(`
      INSERT INTO chat (usuario_id, mensagem, tipo)
      VALUES (?, ?, ?)
    `, [usuarioId, mensagem, tipo]);

    res.status(201).json({ message: 'Mensagem enviada!' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro ao enviar mensagem' });
  }
};
