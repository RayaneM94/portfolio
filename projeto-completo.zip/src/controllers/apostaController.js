const db = require('../models/db');

// Função para processar o resultado da aposta
exports.processarResultado = async (req, res) => {
  const { aposta_id, resultado } = req.body;

  try {
    const [[aposta]] = await db.query(`
      SELECT a.*, u.tipo_usuario, j.titulo
      FROM apostas a
      JOIN usuarios u ON a.usuario_id = u.id
      JOIN jogos j ON a.jogo_id = j.id
      WHERE a.id = ?`, [aposta_id]);

    if (!aposta) {
      return res.status(404).json({ error: 'Aposta não encontrada' });
    }

    if (aposta.status === 'finalizada') {
      return res.status(400).json({ error: 'Aposta já finalizada' });
    }

    let lucro = 0;
    let saldoFinal = aposta.valor;
    if (resultado === 'vitoria') {
      lucro = aposta.valor * aposta.odd - aposta.valor;

      // Calcula comissão
      let comissao = 0.3; // padrão
      if (aposta.tipo_usuario === 'desenvolvedor') {
        comissao = 0.2;
      }

      const lucroLiquido = lucro - lucro * comissao;
      saldoFinal += lucroLiquido;

      await db.query(`UPDATE usuarios SET saldo = saldo + ? WHERE id = ?`, [saldoFinal, aposta.usuario_id]);
    }

    await db.query(`UPDATE apostas SET status = 'finalizada', resultado = ? WHERE id = ?`, [resultado, aposta_id]);

    res.json({ message: 'Aposta finalizada com sucesso.' });
  } catch (err) {
    console.error('Erro ao processar aposta:', err);
    res.status(500).json({ error: 'Erro interno no servidor' });
  }
};
