const db = require('../models/db');

// Cria aposta
exports.criarAposta = async (req, res) => {
  try {
    const { jogo_id, valor } = req.body;
    const usuario_id = req.usuario.id;

    // Verifica saldo
    const [[usuario]] = await db.query('SELECT saldo FROM usuarios WHERE id = ?', [usuario_id]);
    if (!usuario || usuario.saldo < valor) {
      return res.status(400).json({ error: 'Saldo insuficiente.' });
    }

    // Desconta valor
    await db.query('UPDATE usuarios SET saldo = saldo - ? WHERE id = ?', [valor, usuario_id]);

    // Cria aposta
    await db.query(
      'INSERT INTO apostas (usuario_id, jogo_id, valor, status) VALUES (?, ?, ?, ?)',
      [usuario_id, jogo_id, valor, 'pendente']
    );

    res.status(201).json({ message: 'Aposta registrada com sucesso!' });
  } catch (err) {
    console.error('Erro ao criar aposta:', err);
    res.status(500).json({ error: 'Erro ao criar aposta.' });
  }
};

// Finaliza aposta
exports.processarResultado = async (req, res) => {
  try {
    const { aposta_id, resultado, tipo_jogo } = req.body; // resultado = 'vitoria' ou 'derrota'

    const [[aposta]] = await db.query('SELECT * FROM apostas WHERE id = ?', [aposta_id]);
    if (!aposta) return res.status(404).json({ error: 'Aposta não encontrada.' });

    if (aposta.status !== 'pendente') return res.status(400).json({ error: 'Aposta já finalizada.' });

    let valorPremio = 0;

    if (resultado === 'vitoria') {
      // Busca odd
      const [[jogo]] = await db.query('SELECT odd FROM jogos WHERE id = ?', [aposta.jogo_id]);
      const odd = jogo ? jogo.odd : 1.5;

      // Calcula prêmio
      const bruto = aposta.valor * odd;

      let lucro = bruto - aposta.valor;

      // Taxas (definidas pela plataforma)
      const taxaPlataforma = tipo_jogo === 'plataforma' ? 0.3 : 0.2;
      const taxaDev = tipo_jogo === 'dev' ? 0.1 : 0;

      const taxaTotal = lucro * (taxaPlataforma + taxaDev);
      valorPremio = bruto - taxaTotal;

      // Credita no saldo
      await db.query('UPDATE usuarios SET saldo = saldo + ? WHERE id = ?', [valorPremio, aposta.usuario_id]);
    }

    // Atualiza aposta
    await db.query(
      'UPDATE apostas SET status = ?, resultado = ? WHERE id = ?',
      ['finalizada', resultado, aposta_id]
    );

    res.json({
      message: 'Aposta finalizada!',
      resultado,
      valor_creditado: resultado === 'vitoria' ? valorPremio.toFixed(2) : 0
    });

  } catch (err) {
    console.error('Erro ao processar resultado:', err);
    res.status(500).json({ error: 'Erro ao finalizar aposta.' });
  }
};
