module.exports = {
  clientId: 'Client_Id_9470ad8609690cd7d07cf9d6731b62a85e9df1b5',
  clientSecret: 'Client_Secret_eaaf44432d4d19de94d6c2065ca5967307ee06d4',
  pixKey: '57.486.720/0001-26',
  certPath: './certs/certificado.pem',
  keyPath: './certs/private.pem'
};
