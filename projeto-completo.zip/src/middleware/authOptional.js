const jwt = require('jsonwebtoken');

module.exports = function (req, res, next) {
  const token = req.headers['authorization'];

  if (token) {
    try {
      const decoded = jwt.verify(token, 'seu_segredo_jwt');
      req.usuario = decoded;
    } catch (err) {
      console.warn('Token inválido, seguindo sem autenticação.');
    }
  }

  next();
};
