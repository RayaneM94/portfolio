const jwt = require('jsonwebtoken');
require('dotenv').config();

module.exports = (req, res, next) => {
    // 1. Pegar o token do cabeçalho Authorization
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1]; // Formato: "Bearer TOKEN"
    
    // 2. Se não tiver token, retorna erro 401
    if (!token) {
        return res.status(401).json({ 
            error: 'Acesso negado. Token não fornecido.',
            solution: 'Inclua um token válido no header Authorization'
        });
    }

    // 3. Verificar o token
    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        
        // Adiciona os dados do usuário na requisição
        req.user = {
            id: decoded.id,
            email: decoded.email
            // Adicione outros campos se necessário
        };
        
        next(); // Passa para a próxima função/controller
    } catch (error) {
        console.error('Erro na verificação do token:', error);
        
        // Erros específicos
        if (error.name === 'TokenExpiredError') {
            return res.status(401).json({ 
                error: 'Token expirado',
                solution: 'Faça login novamente para obter um novo token'
            });
        }
        
        return res.status(401).json({ 
            error: 'Token inválido',
            details: error.message
        });
    }
};
