const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth');
const twoFAService = require('../services/twoFAService');

// Aplica middleware de autenticação em todas as rotas
router.use(authMiddleware);

// Inicia o setup do 2FA
router.get('/setup', async (req, res) => {
  try {
    const { secret, otpauth_url } = await twoFAService.generate2FASecret(req.userId);
    const qrCode = await twoFAService.generate2FAQrCode(otpauth_url);
    res.json({ secret, qrCode });
  } catch (err) {
    console.error('Erro ao configurar 2FA:', err);
    res.status(500).json({ error: 'Erro ao configurar 2FA' });
  }
});

// Valida o token e ativa o 2FA
router.post('/activate', async (req, res) => {
  try {
    const { token } = req.body;
    if (!token) return res.status(400).json({ error: 'Token não fornecido' });

    const valid = await twoFAService.verify2FAToken(req.userId, token);
    if (!valid) return res.status(400).json({ error: 'Token inválido' });

    await twoFAService.activate2FA(req.userId);
    res.json({ message: '2FA ativado com sucesso!' });
  } catch (err) {
    console.error('Erro ao ativar 2FA:', err);
    res.status(500).json({ error: 'Erro ao ativar 2FA' });
  }
});

module.exports = router;
