// 📁 /src/routes/estatisticasRoutes.js
const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const db = require('../models/db');

// Estatísticas gerais do usuário logado
router.get('/usuario', auth, async (req, res) => {
  try {
    const usuario_id = req.usuario.id;

    const [totalApostas] = await db.query(
      'SELECT COUNT(*) AS total FROM apostas WHERE usuario_id = ?',
      [usuario_id]
    );

    const [totalGanhos] = await db.query(
      "SELECT SUM(valor * odd) AS ganhos FROM apostas WHERE usuario_id = ? AND resultado = 'vitoria'",
      [usuario_id]
    );

    const [totalPerdas] = await db.query(
      "SELECT SUM(valor) AS perdas FROM apostas WHERE usuario_id = ? AND resultado = 'derrota'",
      [usuario_id]
    );

    res.json({
      total_apostas: totalApostas[0].total || 0,
      ganhos: totalGanhos[0].ganhos || 0,
      perdas: totalPerdas[0].perdas || 0
    });
  } catch (err) {
    console.error('Erro nas estatísticas:', err);
    res.status(500).json({ error: 'Erro ao buscar estatísticas' });
  }
});

module.exports = router;
