const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth');
const gnService = require('../services/gerencianetService');

router.post('/gerar-cobranca', authMiddleware, async (req, res) => {
  const { valor } = req.body;

  if (!valor || valor <= 0) {
    return res.status(400).json({ error: 'Valor inválido' });
  }

  try {
    const cobranca = await gnService.gerarCobranca(valor);
    const qrCode = await gnService.gerarQRCode(cobranca.loc.id);

    res.json({ qrcode: qrCode.qrcode, imagemQrcode: qrCode.imagemQrcode });
  } catch (err) {
    console.error('Erro ao gerar cobrança PIX:', err.message);
    res.status(500).json({ error: 'Erro ao gerar cobrança PIX' });
  }
});

module.exports = router;
