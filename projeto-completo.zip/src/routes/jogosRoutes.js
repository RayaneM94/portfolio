const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth');
const db = require('../models/db');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

// 📁 Configuração do multer para salvar os arquivos na pasta "uploads"
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const dir = path.join(__dirname, '../../uploads');
    if (!fs.existsSync(dir)) fs.mkdirSync(dir);
    cb(null, dir);
  },
  filename: function (req, file, cb) {
    const unique = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, unique + '-' + file.originalname);
  }
});
const upload = multer({ storage });

// 🔐 Apenas usuários autenticados podem acessar
router.use(authMiddleware);

// ✅ GET /jogos/listar — Lista todos os jogos cadastrados + total de apostas
router.get('/listar', async (req, res) => {
  try {
    const [jogos] = await db.query(`
      SELECT j.*, COUNT(a.id) AS total_apostas
      FROM jogos j
      LEFT JOIN apostas a ON j.id = a.jogo_id
      GROUP BY j.id
      ORDER BY total_apostas DESC
    `);

    res.json(jogos);
  } catch (err) {
    console.error('Erro ao listar jogos:', err);
    res.status(500).json({ error: 'Erro ao listar jogos.' });
  }
});

// ✅ POST /jogos/upload — Envio de jogos por desenvolvedores
router.post('/upload', upload.single('arquivo'), async (req, res) => {
  try {
    const { titulo, descricao, odd } = req.body;
    const arquivo = req.file;

    if (!arquivo) {
      return res.status(400).json({ error: 'Arquivo não enviado.' });
    }

    await db.query(
      'INSERT INTO jogos (titulo, descricao, odd) VALUES (?, ?, ?)',
      [titulo, descricao, parseFloat(odd)]
    );

    res.status(201).json({ message: 'Jogo enviado com sucesso!' });
  } catch (err) {
    console.error('Erro no upload de jogo:', err);
    res.status(500).json({ error: 'Erro ao enviar jogo.' });
  }
});

module.exports = router;
