const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth');
const db = require('../models/db');

// Pegar saldo e nome
router.get('/', authMiddleware, async (req, res) => {
    try {
        const [user] = await db.query('SELECT nome, saldo FROM usuarios WHERE id = ?', [req.userId]);
        if (!user[0]) {
            return res.status(404).json({ error: 'Usuário não encontrado' });
        }
        res.json(user[0]); 
    } catch (err) {
        console.error('Erro no GET /carteira:', err);
        res.status(500).json({ error: 'Erro ao buscar dados do usuário' });
    }
});

// Adicionar saldo
router.post('/adicionar', authMiddleware, async (req, res) => {
    const { valor } = req.body;
    if (!valor || valor <= 0) {
        return res.status(400).json({ error: 'Valor inválido' });
    }

    try {
        await db.query('UPDATE usuarios SET saldo = saldo + ? WHERE id = ?', [valor, req.userId]);
        res.json({ message: 'Saldo adicionado com sucesso' });
    } catch (err) {
        console.error('Erro no POST /carteira/adicionar:', err);
        res.status(500).json({ error: 'Erro ao adicionar saldo' });
    }
});

// Solicitar saque
router.post('/sacar', authMiddleware, async (req, res) => {
    const { valor } = req.body;
    if (!valor || valor <= 0) {
        return res.status(400).json({ error: 'Valor inválido' });
    }

    try {
        const [user] = await db.query('SELECT saldo FROM usuarios WHERE id = ?', [req.userId]);
        if (!user[0]) {
            return res.status(404).json({ error: 'Usuário não encontrado' });
        }

        if (valor > user[0].saldo) {
            return res.status(400).json({ error: 'Saldo insuficiente' });
        }

        await db.query('UPDATE usuarios SET saldo = saldo - ? WHERE id = ?', [valor, req.userId]);
        res.json({ message: 'Saque realizado com sucesso' });
    } catch (err) {
        console.error('Erro no POST /carteira/sacar:', err);
        res.status(500).json({ error: 'Erro ao realizar saque' });
    }
});

module.exports = router;
