const express = require('express');
const router = express.Router();
const db = require('../models/db');

router.post('/pix', async (req, res) => {
  try {
    const { pix } = req.body;

    if (!pix || !Array.isArray(pix)) {
      return res.status(400).json({ error: 'Payload inválido' });
    }

    for (const pagamento of pix) {
      const { valor, chave, txid } = pagamento;

      // Exemplo: Atualizar saldo do usuário baseado na chave Pix recebida
      // Aqui você teria que localizar o usuário pela chave (ou via lógica de txid)
      await db.query('UPDATE usuarios SET saldo = saldo + ? WHERE chave_pix = ?', [valor, chave]);
    }

    res.status(200).json({ status: 'ok' });
  } catch (err) {
    console.error('Erro no Webhook PIX:', err);
    res.status(500).json({ error: 'Erro interno' });
  }
});

module.exports = router;
