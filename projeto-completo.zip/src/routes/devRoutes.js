const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const db = require('../models/db');

// Rota para listar os jogos de um desenvolvedor com estatísticas
router.get('/meus', auth, async (req, res) => {
  try {
    const userId = req.user.id;

    const [jogos] = await db.query(`
      SELECT j.*, 
             COUNT(a.id) AS total_apostas,
             IFNULL(SUM(a.valor), 0) AS total_lucro
      FROM jogos j
      LEFT JOIN apostas a ON a.jogo_id = j.id
      WHERE j.dev_id = ?
      GROUP BY j.id
    `, [userId]);

    res.json(jogos);
  } catch (err) {
    console.error('Erro ao buscar jogos do dev:', err);
    res.status(500).json({ error: 'Erro ao buscar jogos do dev' });
  }
});

module.exports = router;
