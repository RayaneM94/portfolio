const express = require('express');
const router = express.Router();
const authOptional = require('../middleware/authOptional');
const fs = require('fs');
const path = require('path');

router.get('/listar', authOptional, (req, res) => {
    const jogosDir = path.join(__dirname, '../../public/jogos');
    fs.readdir(jogosDir, (err, files) => {
        if (err) {
            return res.status(500).json({ error: 'Erro ao listar jogos' });
        }
        const jogos = files.filter(file => file.endsWith('.html'));
        res.json({ jogos });
    });
});

module.exports = router;
