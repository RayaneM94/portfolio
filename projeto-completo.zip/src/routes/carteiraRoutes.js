const express = require('express');
const router = express.Router();
const carteiraController = require('../controllers/carteiraController');
const authMiddleware = require('../middlewares/authMiddleware');

// Pegar saldo da carteira
router.get('/saldo', authMiddleware, carteiraController.getSaldo);

// Adicionar saldo (pagamento confirmado)
router.post('/adicionar', authMiddleware, carteiraController.adicionarSaldo);

// Solicitar saque
router.post('/sacar', authMiddleware, carteiraController.solicitarSaque);

module.exports = router;
