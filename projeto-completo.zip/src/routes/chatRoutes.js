const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const chatController = require('../controllers/chatController');

router.get('/', auth, chatController.buscarMensagensGlobal);
router.get('/amigos', auth, chatController.buscarMensagensAmigos);
router.post('/enviar', auth, chatController.enviarMensagem);

module.exports = router;
