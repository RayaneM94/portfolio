// src/routes/rankingRoutes.js
const express = require('express');
const router = express.Router();
const db = require('../models/db');

// Ranking global por saldo
router.get('/', async (req, res) => {
  try {
    const [rows] = await db.query(
      'SELECT nome, saldo FROM usuarios ORDER BY saldo DESC LIMIT 10'
    );
    res.json(rows);
  } catch (err) {
    console.error('Erro ao buscar ranking:', err);
    res.status(500).json({ error: 'Erro ao buscar ranking' });
  }
});

module.exports = router;
