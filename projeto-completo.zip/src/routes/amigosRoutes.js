const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const amigosController = require('../controllers/amigosController');

// Listar amigos do usuário logado
router.get('/', auth, amigosController.listarAmigos);

// Adicionar amigo pelo ID
router.post('/adicionar/:id', auth, amigosController.adicionarAmigo);

// Remover amigo pelo ID
router.delete('/remover/:id', auth, amigosController.removerAmigo);

module.exports = router;
