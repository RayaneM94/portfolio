const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const betController = require('../controllers/betController');

// Registrar uma nova aposta
router.post('/', auth, betController.criarAposta);

// Finalizar aposta e processar resultado
router.post('/finalizar', auth, betController.processarResultado);

module.exports = router;
