const speakeasy = require('speakeasy');
const QRCode = require('qrcode');
const db = require('../models/db');

exports.generate2FASecret = async (userId) => {
  const secret = speakeasy.generateSecret({ name: `Compet.sport (${userId})` });

  await db.query(
    'UPDATE usuarios SET dois_fa_secret = ?, dois_fa_ativo = FALSE WHERE id = ?',
    [secret.base32, userId]
  );

  return {
    secret: secret.base32,
    otpauth_url: secret.otpauth_url
  };
};

exports.generate2FAQrCode = async (otpauthUrl) => {
  return await QRCode.toDataURL(otpauthUrl);
};

exports.verify2FAToken = async (userId, token) => {
  const [result] = await db.query('SELECT dois_fa_secret FROM usuarios WHERE id = ?', [userId]);
  if (!result.length || !result[0].dois_fa_secret) throw new Error('2FA não configurado');

  const secret = result[0].dois_fa_secret;
  return speakeasy.totp.verify({
    secret,
    encoding: 'base32',
    token,
    window: 1
  });
};

exports.activate2FA = async (userId) => {
  await db.query('UPDATE usuarios SET dois_fa_ativo = TRUE WHERE id = ?', [userId]);
};
