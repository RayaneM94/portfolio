const axios = require('axios');
const fs = require('fs');
const https = require('https');

const clientId = 'SEU_CLIENT_ID';
const clientSecret = 'SEU_CLIENT_SECRET';
const pixKey = 'SUA_CHAVE_PIX'; // sua chave pix cadastrada na Gerencianet

const httpsAgent = new https.Agent({
  cert: fs.readFileSync('./certs/certificado.pem'),
  key: fs.readFileSync('./certs/private.pem'),
  rejectUnauthorized: false
});

async function getAccessToken() {
  const auth = Buffer.from(`${clientId}:${clientSecret}`).toString('base64');

  const response = await axios.post(
    'https://api-pix-h.gerencianet.com.br/oauth/token',
    'grant_type=client_credentials',
    {
      httpsAgent,
      headers: {
        Authorization: `Basic ${auth}`,
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    }
  );

  return response.data.access_token;
}

async function gerarCobranca(valor) {
  try {
    const token = await getAccessToken();

    const body = {
      calendario: { expiracao: 3600 },
      valor: { original: parseFloat(valor).toFixed(2) },
      chave: pixKey,
      solicitacaoPagador: 'Depósito Compet.Esport'
    };

    const response = await axios.post(
      'https://api-pix-h.gerencianet.com.br/v2/cob',
      body,
      {
        httpsAgent,
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      }
    );

    return response.data;
  } catch (err) {
    console.error('Erro ao gerar cobrança:', err.response ? err.response.data : err.message);
    throw err;
  }
}

async function gerarQRCode(locId) {
  const token = await getAccessToken();

  const response = await axios.get(
    `https://api-pix-h.gerencianet.com.br/v2/loc/${locId}/qrcode`,
    {
      httpsAgent,
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    }
  );

  return response.data;
}

// Exemplo de uso:
(async () => {
  try {
    const cobranca = await gerarCobranca(50); // valor R$50
    console.log('Cobrança:', cobranca);

    const qrCode = await gerarQRCode(cobranca.loc.id);
    console.log('QR Code:', qrCode);
  } catch (err) {
    console.error('Erro:', err.message);
  }
})();
