const mysql = require('mysql2');

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'appuser',
  password: 'appsenha123',
  database: 'plataforma_apostas'
});

connection.connect(err => {
  if (err) {
    console.error('Erro ao conectar ao MySQL:', err);
  } else {
    console.log('Conexão com MySQL bem-sucedida!');
  }
});

module.exports = connection;
