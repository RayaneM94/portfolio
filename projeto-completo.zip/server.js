const http = require('http');
const url = require('url');
const fs = require('fs');
const path = require('path');
const db = require('./db_mysql');
const querystring = require('querystring');

const server = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url, true);
  const method = req.method;

  // ===== Servir página de login =====
  if (method === 'GET' && parsedUrl.pathname === '/login.html') {
    const filePath = path.join(__dirname, 'public', 'login.html');
    fs.readFile(filePath, (err, content) => {
      if (err) {
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        res.end('Erro ao carregar a página de login.');
      } else {
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(content);
      }
    });
  }

  // ===== Servir página de cadastro =====
  else if (method === 'GET' && parsedUrl.pathname === '/cadastro.html') {
    const filePath = path.join(__dirname, 'public', 'cadastro.html');
    fs.readFile(filePath, (err, content) => {
      if (err) {
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        res.end('Erro ao carregar a página de cadastro.');
      } else {
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(content);
      }
    });
  }

  // ===== Servir arquivos CSS =====
  else if (method === 'GET' && parsedUrl.pathname.startsWith('/css/')) {
    const filePath = path.join(__dirname, 'public', parsedUrl.pathname);
    fs.readFile(filePath, (err, content) => {
      if (err) {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('CSS não encontrado.');
      } else {
        res.writeHead(200, { 'Content-Type': 'text/css' });
        res.end(content);
      }
    });
  }

  // ===== Servir imagens (como o fundo do login) =====
  else if (method === 'GET' && parsedUrl.pathname.startsWith('/images/')) {
    const filePath = path.join(__dirname, 'public', parsedUrl.pathname);
    fs.readFile(filePath, (err, content) => {
      if (err) {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('Imagem não encontrada.');
      } else {
        // Tipo de conteúdo da imagem (jpeg, png, etc)
        const ext = path.extname(filePath).toLowerCase();
        const contentType = ext === '.png' ? 'image/png' : 'image/jpeg';
        res.writeHead(200, { 'Content-Type': contentType });
        res.end(content);
      }
    });
  }

  // ===== Rota para cadastro de usuário (POST) =====
  else if (method === 'POST' && parsedUrl.pathname === '/cadastro') {
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
    });

    req.on('end', () => {
      const dados = querystring.parse(body);
      const nome = dados.nome;
      const email = dados.email;
      const senha = dados.senha;

      const sql = 'INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)';
      db.query(sql, [nome, email, senha], (err, result) => {
        if (err) {
          console.error('Erro ao cadastrar usuário:', err);
          res.writeHead(500, { 'Content-Type': 'text/plain' });
          res.end('Erro ao cadastrar usuário.');
        } else {
          res.writeHead(302, { Location: '/login.html' });
          res.end();
        }
      });
    });
  }

  // ===== Rota de login (POST) =====
  else if (method === 'POST' && parsedUrl.pathname === '/login') {
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
    });

    req.on('end', () => {
      const dados = querystring.parse(body);
      const email = dados.email;
      const senha = dados.senha;

      const sql = 'SELECT * FROM usuarios WHERE email = ? AND senha = ?';
      db.query(sql, [email, senha], (err, results) => {
        if (err) {
          console.error('Erro ao fazer login:', err);
          res.writeHead(500, { 'Content-Type': 'text/plain' });
          res.end('Erro ao fazer login.');
        } else if (results.length > 0) {
          res.writeHead(200, { 'Content-Type': 'text/plain' });
          res.end('Login bem-sucedido!');
        } else {
          res.writeHead(401, { 'Content-Type': 'text/plain' });
          res.end('Email ou senha incorretos.');
        }
      });
    });
  }

  // ===== Se nenhuma rota for encontrada =====
  else {
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('Rota não encontrada.');
  }
});

server.listen(3001, () => {
  console.log('Servidor rodando na porta 3001');
});

