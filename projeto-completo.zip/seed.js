const db = require('./db');

const jogos = [
  { nome: 'Jogo de Habilidade: Corrida Maluca' },
  { nome: 'Jogo de Tiro ao Alvo Virtual' },
  { nome: 'Desafio de Reflexo: Clique Rápido' }
];

jogos.forEach(jogo => {
  db.run('INSERT INTO jogos (nome) VALUES (?)', [jogo.nome], function(err) {
    if (err) {
      console.error('Erro ao inserir jogo:', err.message);
    } else {
      console.log(`Jogo inserido com ID: ${this.lastID}`);
    }
  });
});
