require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();

// Middlewares
app.use(express.json());
app.use(cors());

// Servir arquivos estáticos (HTML, CSS, JS)
app.use(express.static(path.resolve(__dirname, 'public')));

// Rotas principais
app.use('/auth', require('./src/routes/authRoutes'));
app.use('/apostas', require('./src/routes/betRoutes'));
app.use('/carteira', require('./src/routes/walletRoutes'));
app.use('/2fa', require('./src/routes/twoFARoutes'));
app.use('/dev', require('./src/routes/devRoutes')); // <- para cadastrar novos jogos
app.use('/amigos', require('./src/routes/amigosRoutes'));
app.use('/chat', require('./src/routes/chatRoutes'));
app.use('/estatisticas', require('./src/routes/estatisticasRoutes'));
app.use('/ranking', require('./src/routes/rankingRoutes'));
//app.use('/pagamentos', require('./src/routes/pixRoutes'));
//app.use('/webhook', require('./src/routes/pixWebhookRoutes'));
app.use('/jogos', require('./src/routes/jogosListRoutes'));

// Tratamento de erro genérico
app.use((err, req, res, next) => {
  console.error('Erro interno:', err.stack);
  res.status(500).json({ error: 'Erro interno no servidor' });
});

// Inicializa servidor
const PORT = process.env.PORT || 3001;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`🟢 Servidor rodando na porta ${PORT}`);
});
