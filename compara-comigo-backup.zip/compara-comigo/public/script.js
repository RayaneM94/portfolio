let lat = null;
let lng = null;
let map;
let marker = null;

if (navigator.geolocation) {
  navigator.geolocation.getCurrentPosition(
    (position) => {
      lat = position.coords.latitude;
      lng = position.coords.longitude;
      iniciarMapa(lat, lng);
    },
    (err) => {
      console.error('Erro ao obter localização', err);
      // Fallback: centro do Rio
      iniciarMapa(-22.9068, -43.1729);
    }
  );
} else {
  alert('Geolocalização não suportada.');
  iniciarMapa(-22.9068, -43.1729);
}

function iniciarMapa(latitude, longitude) {
  map = L.map('map').setView([latitude, longitude], 14);

  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors'
  }).addTo(map);

  map.on('click', function (e) {
    lat = e.latlng.lat;
    lng = e.latlng.lng;

    if (marker) {
      map.removeLayer(marker);
    }

    marker = L.marker([lat, lng]).addTo(map);
  });
}

document.getElementById('priceForm').addEventListener('submit', async function (e) {
  e.preventDefault();

  const produto = document.getElementById('produto').value;
  const marca = document.getElementById('marca').value;
  const comercio = document.getElementById('comercio').value;
  const preco = parseFloat(document.getElementById('preco').value);
  const nota = parseInt(document.getElementById('nota').value);
  const atendimento = parseInt(document.getElementById('atendimento').value);
  const conservacao = parseInt(document.getElementById('conservacao').value);
  const higiene = parseInt(document.getElementById('higiene').value);

  if (!lat || !lng) {
    alert('Clique no mapa para selecionar a localização!');
    return;
  }

   const data = {
   produto, comercio, preco, lat, lng,
   nota, atendimento, conservacao, higiene
  };

  const res = await fetch('http://localhost:3000/api/precos', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });

  if (res.ok) {
    alert('Preço salvo!');
    document.getElementById('priceForm').reset();
    map.removeLayer(marker);
    lat = null;
    lng = null;
  } else {
    alert('Erro ao salvar.');
  }
});
