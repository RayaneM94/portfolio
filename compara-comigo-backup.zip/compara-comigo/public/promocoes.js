async function carregarPromocoes() {
  const res = await fetch("http://localhost:3000/api/precos");
  const dados = await res.json();

  const container = document.getElementById("cards-container");

  container.innerHTML = "";

  dados.forEach(item => {
    const card = document.createElement("div");
    card.className = "card";

    card.innerHTML = `
    <h3>${item.produto}</h3>
    <p><strong>Marca:</strong> ${item.marca || 'Não informada'}</p>
    <p><strong>Comércio:</strong> ${item.comercio}</p>
    <p><strong>Preço:</strong> R$ ${item.preco.toFixed(2)}</p>
    <p><strong>Data:</strong> ${new Date(item.data_hora).toLocaleDateString()}</p>
    <p><strong>Avaliação:</strong> ${'★'.repeat(item.nota || 0)}</p>
    <p><strong>Atendimento:</strong> ${item.atendimento || 'Não informado'}</p>
    <p><strong>Higiene:</strong> ${item.higiene || 'Não informado'}</p>
    <p><strong>Conservação:</strong> ${item.conservacao || 'Não informado'}</p>
  `;

    container.appendChild(card);
  });
}

carregarPromocoes();
document.getElementById("btnBuscar").addEventListener("click", async () => {
  const termo = document.getElementById("busca").value.trim().toLowerCase();

  const res = await fetch("http://localhost:3000/api/precos");
  const dados = await res.json();

  const resultado = dados.filter(item =>
    item.produto.toLowerCase().includes(termo)
  );

  const container = document.getElementById("cards-container");
  container.innerHTML = "";

  if (resultado.length === 0) {
    container.innerHTML = `<p style="margin-left:20px;">❌ No momento não há promoção desse produto.</p>`;
    return;
  }

  resultado.forEach(item => {
    const card = document.createElement("div");
    card.className = "card";

    card.innerHTML = `
      <h3>${item.produto}</h3>
      <p><strong>Marca:</strong> ${item.marca || 'Não informada'}</p>
      <p><strong>Comércio:</strong> ${item.comercio}</p>
      <p><strong>Preço:</strong> R$ ${item.preco.toFixed(2)}</p>
      <p><strong>Data:</strong> ${new Date(item.data_hora).toLocaleDateString()}</p>
      <p><strong>Avaliação:</strong> ${'★'.repeat(item.nota || 0)}</p>
      <p><strong>Atendimento:</strong> ${item.atendimento || 'Não informado'}</p>
      <p><strong>Higiene:</strong> ${item.higiene || 'Não informado'}</p>
      <p><strong>Conservação:</strong> ${item.conservacao || 'Não informado'}</p>
    `;

    card.addEventListener("click", () => {
      localStorage.setItem("lat", item.lat);
      localStorage.setItem("lng", item.lng);
      window.location.href = "index.html";
    });

    container.appendChild(card);
  });
});
