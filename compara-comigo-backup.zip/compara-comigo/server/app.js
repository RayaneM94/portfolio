const express = require('express');
const cors = require('cors');
const bcrypt = require('bcrypt');
const db = require('./db');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
const path = require('path');
app.use(express.static(path.join(__dirname, '..', 'public')));

// Rota para salvar preço
app.post('/api/precos', (req, res) => {
const { produto, marca, comercio, preco, lat, lng, nota, atendimento, conservacao, higiene } = req.body;

  const query = `
  INSERT INTO precos (produto, marca, comercio, preco, lat, lng, nota, atendimento, conservacao, higiene)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)

  db.run(query, [produto, marca, comercio, preco, lat, lng, nota, atendimento, conservacao, higiene], function (err) {
    if (err) {
      console.error(err.message);
      return res.status(500).json({ error: 'Erro ao inserir preço' });
    }

    res.json({ id: this.lastID });
  });
});

// Rota para listar todos os preços
app.get('/api/precos', (req, res) => {
  db.all("SELECT * FROM precos", [], (err, rows) => {
    if (err) {
      console.error(err.message);
      return res.status(500).json({ error: 'Erro ao listar preços' });
    }
    res.json(rows);
  });
});

// Rota para cadastrar usuários
app.post('/api/cadastrar', async (req, res) => {
  const { nome, email, senha, tipo } = req.body;
  
  if (!nome || !email || !senha || !tipo) {
    return res.status(400).json({ message: 'Todos os campos são obrigatórios.' });
  }

  try {
    const senhaHash = await bcrypt.hash(senha, 10);

    const query = `
      INSERT INTO usuarios (nome, email, senha, tipo)
      VALUES (?, ?, ?, ?)
    `;

    db.run(query, [nome, email, senhaHash, tipo], function (err) {
      if (err) {
        console.error(err.message);
        return res.status(500).json({ message: 'Erro ao cadastrar usuário' });
      }
      res.json({ message: 'Usuário cadastrado com sucesso' });
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Erro interno no servidor' });
  }
});

// Rota de login
app.post('/api/login', (req, res) => {
  const { email, senha } = req.body;

  db.get('SELECT * FROM usuarios WHERE email = ?', [email], async (err, usuario) => {
    if (err) {
      console.error(err.message);
      return res.status(500).json({ message: 'Erro no servidor' });
    }

    if (!usuario) {
      return res.status(401).json({ message: 'Usuário não encontrado' });
    }

    const match = await bcrypt.compare(senha, usuario.senha);
    if (!match) {
      return res.status(401).json({ message: 'Senha incorreta' });
    }

    res.json({
      id: usuario.id,
      nome: usuario.nome,
      email: usuario.email,
      tipo: usuario.tipo
    });
  });
});

// Cadastro de usuários
app.post('/api/cadastro', (req, res) => {
  const { nome, email, senha, tipo } = req.body;

  const query = `
    INSERT INTO usuarios (nome, email, senha, tipo)
    VALUES (?, ?, ?, ?)
  `;

  db.run(query, [nome, email, senha, tipo], function (err) {
    if (err) {
      console.error(err.message);
      return res.status(500).json({ error: 'Erro ao cadastrar usuário' });
    }

    res.json({ success: true });
  });
});

// Inicialização do servidor
app.listen(PORT, () => {
  console.log(`🔥 Servidor rodando em http://localhost:${PORT}`);
});
